const express = require("express");
const router = express.Router();
const authMiddleware = require("../middleware/auth");
const Habit = require("../models/Habit");
const HabitLog = require("../models/HabitLog");

// ✅ GET /api/habits — fetch all habits for the user
router.get("/", authMiddleware, async (req, res) => {
  try {
    const habits = await Habit.find({ userId: req.userId });
    res.json(habits);
  } catch (err) {
    console.error("Failed to fetch habits:", err);
    res.status(500).json({ error: "Could not fetch habits" });
  }
});

// ✅ POST /api/habits/log — log a habit entry
router.post("/log", authMiddleware, async (req, res) => {
  try {
    const { habitId, note, date } = req.body;

    const log = new HabitLog({
      userId: req.userId,
      habitId,
      note,
      date: date ? new Date(date) : new Date(),
    });

    await log.save();
    res.status(201).json(log);
  } catch (err) {
    console.error("Failed to log habit:", err);
    res.status(500).json({ error: "Could not log habit" });
  }
});

module.exports = router;
